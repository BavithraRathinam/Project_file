package com.accessoryService.DAOImpl;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.accessoryService.DAO.SalesDAO;
import com.accessoryService.RowMapper.AccessoryRowMapper;
import com.accessoryService.RowMapper.SaleCountRowMapper;
import com.accessoryService.RowMapper.SalesRowMapper;
import com.accessoryService.model.Sales;

@Repository
public class SalesDAOImpl implements SalesDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	

	@Override
	public List<Sales> findHighSaleVehicle(Date sdate,Date edate) {
		String sql="select x.series_model_year,year(x.sale_date) as year,x.region,\r\n" + 
				"count(x.sale_date) as sale_count from  salesdetails x inner join \r\n" + 
				"(select s.series_model_year from salesdetails s where sale_date between ? and ?\r\n" + 
				" group by s.series_model_year having count(s.sale_date)=\r\n" + 
				"(select max(count) from (select count(sale_date)as count from salesdetails\r\n" + 
				"where sale_date between ? and ? group by series_model_year)y))z\r\n" + 
				"where x.series_model_year=z.series_model_year and sale_date between ? and ?\r\n" + 
				"group by year(x.sale_date),x.series_model_year,region order by year";
		List<Sales> query = jdbcTemplate.query(sql, new SalesRowMapper(),sdate,edate,sdate,edate,sdate,edate);
		return query;
	}

	@Override
	public List<Sales> findLowSaleVehicle(Date sdate,Date edate) {
		String sql="select x.series_model_year,year(x.sale_date) as year,x.region,\r\n" + 
				"count(x.sale_date) as sale_count from  salesdetails x inner join \r\n" + 
				"(select s.series_model_year from salesdetails s where sale_date between ? and ?\r\n" + 
				" group by s.series_model_year having count(s.sale_date)=\r\n" + 
				"(select min(count) from (select count(sale_date)as count from salesdetails\r\n" + 
				"where sale_date between ? and ? group by series_model_year)y))z\r\n" + 
				"where x.series_model_year=z.series_model_year and sale_date between ? and ?\r\n" + 
				"group by year(x.sale_date),x.series_model_year,region order by year";
		List<Sales> query = jdbcTemplate.query(sql, new SalesRowMapper(),sdate,edate,sdate,edate,sdate,edate);
		return query;
	}
	
	@Override
	public List<Sales> findByConstraints(Date sdate,Date edate,String seriesYearModel) {
		String sql="select series_model_year,year(sale_date) as year,region,\r\n" + 
				"count(sale_date) as sale_count from salesdetails\r\n" + 
				" where sale_date between ? and ? and \r\n" + 
				" series_model_year=? group by year(sale_date),region order by year";
		List<Sales> query = jdbcTemplate.query(sql, new SalesRowMapper(),
				sdate,edate,seriesYearModel);
		return query;
	}
	
	@Override
	public List<Sales> findAccessories(Date sdate,Date edate,String access) {
		String sql="select x.series_model_year,year(x.sale_date) as year,x.region,\r\n" + 
				"count(x.sale_date) as sale_count from  salesdetails x inner join \r\n" + 
				"(select s.series_model_year from salesdetails s where sale_date between ? and ?\r\n" + 
				" group by s.series_model_year having count(s.sale_date)=\r\n" + 
				"(select max(count) from (select count(sale_date)as count from salesdetails\r\n" + 
				"where sale_date between ? and ? group by series_model_year)y))z\r\n" + 
				"where x.series_model_year=z.series_model_year and sale_date between ? and ?\r\n" + 
				"and find_in_set(?,accessories)\r\n" + 
				"group by year(x.sale_date),x.series_model_year,region order by year";
		List<Sales> query = jdbcTemplate.query(sql, new SalesRowMapper(),
				sdate,edate,sdate,edate,sdate,edate,access);
		return query;
	}

	@Override
	public String findHighSaleVehicleByModelCode(Date sdate, Date edate) {
		String sql="select max(series_model_year) as model from salesdetails\r\n" + 
				"where sale_date between ? and ?";
		String query = jdbcTemplate.query(sql, new AccessoryRowMapper(),sdate,edate).get(0);
		return query.split(":")[2];
	}

	@Override
	public String findLowSaleVehicleByModelCode(Date sdate, Date edate) {
		String sql="select min(series_model_year) as model from salesdetails\r\n" + 
				"where sale_date between ? and ?";
		String query = jdbcTemplate.query(sql, new AccessoryRowMapper(),sdate,edate).get(0);
		return query.split(":")[2];
	}
	
	@Override
	public List<Sales> findHighSaleAccessory(String accessory, Date sdate, Date edate) {
		String sql="select ? as accessory,year(sale_date) as year,region,\r\n" + 
				"count(sale_date) as sale_count from salesdetails where\r\n" + 
				"sale_date between ? and ? and\r\n" + 
				"find_in_set(?,accessories) group by region,year(sale_date)";
		List<Sales> query = jdbcTemplate.query(sql, new SalesRowMapper(),accessory,sdate,edate,accessory);
		return query;
	}

	@Override
	public Integer findAccessorySaleCount(String accessory,Date sdate,Date edate) {
		String sql="select count(sale_date) as sale_count from salesdetails where\r\n" + 
				"sale_date between ? and ? and\r\n" + 
				"find_in_set(?,accessories)";
		Integer val = jdbcTemplate.query(sql, new SaleCountRowMapper(),sdate,edate,accessory).get(0);
		return val;
		
	}

}
