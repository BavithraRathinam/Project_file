package com.accessoryService.controller;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.accessoryService.DAO.SMSClient;
import com.accessoryService.dto.MailRequest;
import com.accessoryService.dto.MailResponse;
import com.accessoryService.model.Sales;
import com.accessoryService.model.SalesGraphPojo;
import com.accessoryService.service.EmailService;
import com.accessoryService.service.SalesService;

@RestController
@RequestMapping("/accessoryService")
public class AccessoryController {
	
	@Autowired
	private SalesService ss;
	@Autowired
	private SMSClient sms;
	@Autowired
	private EmailService service;
	
	@GetMapping("/sales")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Sales> readAllSales() {
		
		return null;
	} 
	
	@GetMapping("/highSales/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> findHighSaleVehicle(@PathVariable("sdate") String sdate,
			@PathVariable("edate") String edate) throws ParseException {
		List<SalesGraphPojo> sgp=ss.findHighSale(sdate, edate);
		return sgp;
	}
	
	@GetMapping("/lowSales/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> findLowSaleVehicle(@PathVariable("sdate") String sdate,
			@PathVariable("edate") String edate) throws ParseException {
		List<SalesGraphPojo> sgp=ss.findLowSale(sdate, edate);
		return sgp;
	}
	
	@GetMapping("/sales/{sdate}/{edate}/{modelSeriesYear}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> findByConstraints(@PathVariable("sdate") String sdate,
			@PathVariable("edate") String edate, @PathVariable("modelSeriesYear")
			String modelSeriesYear) throws ParseException {
		System.out.println(edate+sdate+modelSeriesYear);
		List<SalesGraphPojo> sale=ss.findByConstraints(sdate, edate, modelSeriesYear);
		return sale;
	}
	
	@GetMapping("/accessoriesMax/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> getHighSaleAccessory(@PathVariable String sdate,@PathVariable String edate) throws ParseException {
		String modelCode=ss.findHighSaleByModelCode(sdate, edate);
		List<String> accs=sms.getAccessories(modelCode);
		List<SalesGraphPojo> sgp=ss.findHighSaleAccessory(accs,sdate,edate);
		return sgp;
	}
	
	@GetMapping("/accessoriesMin/{sdate}/{edate}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<SalesGraphPojo> getLowSaleAccessory(@PathVariable String sdate,@PathVariable String edate) throws ParseException {
		String modelCode=ss.findLowSaleByModelCode(sdate, edate);
		List<String> accs=sms.getAccessories(modelCode);
		List<SalesGraphPojo> sgp=ss.findLowSaleAccessory(accs,sdate,edate);
		return sgp;
	}
	
	@GetMapping("/getGeneratedPdf")
	@CrossOrigin(origins = "http://localhost:4200")
	public String geGeneratedPdf() {
		System.out.println("working");
		return "working";
	}
	
	@PostMapping("/sendEmail")
	@CrossOrigin(origins = "http://localhost:4200")
	public MailResponse sendEmail(@RequestBody MailRequest request) {
		Map<String,String> model=new HashMap<>();
		model.put("name", request.getName());
		model.put("location", "Erode");
		return service.sendEmail(request, model);
	}

}
