package com.seriesModelService.DAOImpl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.seriesModelService.DAO.SMSDao;
import com.seriesModelService.rowMapper.SMSRowMapper;

@Repository
public class SMSDaoImpl implements SMSDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<String> findAllSeries() {
		String sql="select series from series";
		List<String> str=jdbcTemplate.query(sql, new SMSRowMapper());
		return str ;
	}

	@Override
	public List<String> findModelYearBySeries(String series) {
		String sql="select m.model_year from series s inner join modelyear m on s.id=m.series_id where s.series=?";
		List<String> str=jdbcTemplate.query(sql, new SMSRowMapper(), series);
		return str ;
	}

	@Override
	public List<String> findModelCodeBySeriesAndYear(String series, String year) {
		String sql="select mc.model_code from series s inner join \r\n" + 
				"modelyear my on s.id=my.series_id inner join modelcode mc\r\n" + 
				"on my.id=mc.modelyear_id where s.series=? and my.model_year=?";
		List<String> str=jdbcTemplate.query(sql, new SMSRowMapper(), series,year);
		return str ;
	}

	@Override
	public List<String> findModelCodeBySeries(String series) {
		String sql="select m.model_code from series s inner join modelcode m on s.id=m.series_id where s.series=?";
		List<String> str=jdbcTemplate.query(sql, new SMSRowMapper(), series);
		return str ;
	}

	@Override
	public List<String> findAccessoryByModelCode(String modelCode) {
		String sql="select a.accessory from accessory a inner join modelcode mc on a.modelcode_id=mc.id where \r\n" + 
				"mc.model_code=?";
		List<String> str=Arrays.asList((jdbcTemplate.query(sql, new SMSRowMapper(), modelCode).get(0).split(",")));
		
		return str ;
	}

}
