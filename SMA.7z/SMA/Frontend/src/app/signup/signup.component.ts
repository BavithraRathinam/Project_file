import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MustMatch} from './custom-val';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signUpForm:FormGroup;
  securityQuestions=['what\'s your childhood nick name', 'who\'s your favourite actor','what\'s your pet name']
  
  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.signUpForm=this.formBuilder.group({
      'username':[null,Validators.required],
      'email':[null,[Validators.required,Validators.email]],
      'password':[null,[Validators.required,Validators.minLength(5)]],
      're-enterPassword':[null,Validators.required],
      'securityQuestion':['what\'s your childhood nick name',Validators.required],
      'sqa':[null,Validators.required]
    },{
      validator: MustMatch('password','re-enterPassword')
    });
  }

}
