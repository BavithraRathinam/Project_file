import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaGrapComponent } from './ana-grap.component';

describe('AnaGrapComponent', () => {
  let component: AnaGrapComponent;
  let fixture: ComponentFixture<AnaGrapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaGrapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaGrapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
