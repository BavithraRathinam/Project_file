
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchComponent } from './search/search.component';
import { AnaGrapComponent } from './ana-grap/ana-grap.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AdminComponent } from './login/admin/admin.component';
import { UserComponent } from './login/user/user.component';

const appRoutes:Routes=[
  {path: 'dashboard', component:DashboardComponent},
  {path: 'user', component:UserComponent},
  {path: 'admin', component:AdminComponent},
  {path: 'search', component:SearchComponent},
  {path: 'signup', component:SignupComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    SearchComponent,
    AnaGrapComponent,
    LoginComponent,
    SignupComponent,
    AdminComponent,
    UserComponent,
  ],
  imports: [
    BrowserAnimationsModule,
    NgxChartsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [AnaGrapComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
